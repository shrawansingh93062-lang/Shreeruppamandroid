SHREE RUPPAM INTERLOCKS — ANDROID APP PROJECT

Yeh Android Studio project hai. Is ZIP mein APK file pehle se compiled nahi hai.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio > Open par click karein aur is ZIP ko extract karke ShreeRuppamAndroid folder kholein.
3. Gradle sync complete hone dein (internet zaroori hai).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5. Build complete hone par app/build/outputs/apk/debug/app-debug.apk milega.
6. APK ko apne Android phone par bhej kar install karein. Phone par unknown apps install permission mang sakti hai.

App name: Shree Ruppam Interlocks
Package: com.shreeruppam.interlocks
Version: 1.0

Note: Google Play Store par publish karne ke liye alag signed release build, Play Console account, privacy/data disclosures aur store listing ki zaroorat ho sakti hai.
